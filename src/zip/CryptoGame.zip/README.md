# Crypto Mining Simulator

## Ievads
Crypto Mining Simulator ir spēle, kas simulē kriptovalūtas (Bitcoin) ieguves procesu. Spēlētāji var iegādāties iekārtas, uzlabot tās un pārvaldīt savu kriptovalūtas ieguves biznesu. Spēle izmanto reāllaika Bitcoin kursu, lai nodrošinātu autentisku pieredzi.

### Galvenās funkcijas:
- Reāllaika Bitcoin kursa atjaunināšana
- Iekārtu (stendu) pārvaldība
- Videokaršu un dzesētāju iegāde un uzstādīšana
- Kriptovalūtas pārdošana pa reālo tirgus cenu
- Inventāra pārvaldība

## Lietotāja interfeiss

### Galvenā izvēlne
Galvenā izvēlne piedāvā šādas opcijas:
1. Inventārs - apskatīt un pārvaldīt savas iekārtas
2. Apskatīt ieguves statusu - skatīt pašreizējo ieguves ātrumu un BTC bilanci
3. Veikals - iegādāties jaunas iekārtas un komponentes
4. Pārdot kriptovalūtu - pārdot iegūto Bitcoin
5. Pārvaldīt ieguves stendus - uzstādīt un pārvaldīt iekārtas

### Inventāra sadaļa
- Rāda visus jūsu iegādātos komponentus
- Ļauj noņemt komponentes no inventāra
- Parāda katra komponenta specifikācijas

### Veikala sadaļa
Pieejamie produkti:
- Videokartes (4 veidu retums):
  - Parasta (1000$)
  - Reta (5000$)
  - Episka (10000$)
  - Mistiska (20000$)
- Dzesētāji (4 veidu retums):
  - Parasts (500$)
  - Retais (1000$)
  - Episkais (5000$)
  - Mistiskais (10000$)
- Ieguves stendi (10000$)
- Stendu uzlabojumi (2000$)

### Ieguves stendu sadaļa
- Uzstādīt videokartes un dzesētājus
- Noņemt komponentes
- Skatīt stendu efektivitāti
- Uzlabot stendus

## Funkciju apraksts

### Kriptovalūtas ieguve
1. Iegādājieties stendu veikalā
2. Uzstādiet videokartes stendā
3. Pievienojiet dzesētājus, lai uzlabotu efektivitāti
4. Sekojiet ieguves ātrumam statusa sadaļā

### Komponentu pārvaldība
1. Iegādājieties komponentes veikalā
2. Uzstādiet tās stendā, izmantojot komandu "install"
3. Noņemiet komponentes, izmantojot komandu "remove"
4. Sekojiet inventāra ietilpībai (maksimums 25 vienības)

### Kriptovalūtas pārdošana
1. Ievadiet komandu "BTC [daudzums]" vai "BTC all"
2. Pārbaudiet pārdošanas cenu
3. Apstipriniet pārdošanu
4. Saņemiet dolārus par pārdoto Bitcoin

### Palīdzības komandas
- "help" - parāda vispārīgu palīdzību
- "help [sadaļa]" - parāda konkrētas sadaļas komandas
- "help [komanda]" - parāda detalizētu palīdzību par konkrētu komandu

## Sākšana
1. Sāciet ar 1000000$ sākuma bilanci
2. Iegādājieties pirmo stendu
3. Uzstādiet videokartes
4. Sāciet iegūt Bitcoin
5. Pārdodiet iegūto kriptovalūtu, lai iegūtu vairāk naudas jaunām iegādēm